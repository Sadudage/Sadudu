import pyecharts.options as opts
from pyecharts.charts import Line, Bar, Grid,Candlestick,Kline
from pyecharts.charts import Page
from pyecharts.globals import CurrentConfig, NotebookType
CurrentConfig.NOTEBOOK_TYPE = NotebookType.JUPYTER_LAB

#折线图定义
def generate_line_chart(line_data,name,colors):
    xaxis = []
    yaxis = []
    for each in line_data:
        xaxis.append(each[0])
        yaxis.append(each[1])

    line_chart = Line()
    line_chart.add_xaxis(xaxis_data=xaxis)
    line_chart.add_yaxis(series_name=name, y_axis=yaxis)
    line_chart.set_series_opts(
        linestyle_opts=opts.LineStyleOpts(width=2, color=colors)  # 设置折线宽度为 2
    )
    return line_chart
#作图函数定义-K线图
def generate_kindle_chart(kindle_data, name="Default Chart"):
    kindle_chart=(
            Kline()
            .add_xaxis(["day{}".format(i) for i in range(len(kindle_data))])
            .add_yaxis(
                name,
                kindle_data,
                itemstyle_opts=opts.ItemStyleOpts(color="#ec0000",color0="#00da3c",border_color="#8A0000",border_color0="#008F28",),
                        )
            .set_global_opts(
                xaxis_opts=opts.AxisOpts(is_scale=True),
                yaxis_opts=opts.AxisOpts(
                                        is_scale=True,
                                        splitarea_opts=opts.SplitAreaOpts(is_show=True, areastyle_opts=opts.AreaStyleOpts(opacity=1)),
                                        ),
                datazoom_opts=[opts.DataZoomOpts(type_="inside")],
                title_opts=opts.TitleOpts(title="K线图"),
                            )
                )
    return kindle_chart

#矩形图生成定义(需要和折线图一起生成)
def generate_line_chart_square_area(line_data,name,colors,markarea):
    xaxis = []
    yaxis = []
    for each in line_data:
        xaxis.append(each[0])
        yaxis.append(each[1])

    line_chart = Line()
    line_chart.add_xaxis(xaxis_data=xaxis)
    line_chart.add_yaxis(series_name=name, y_axis=yaxis)
    line_chart.set_series_opts(
        linestyle_opts=opts.LineStyleOpts(width=2, color=colors),  # 设置折线宽度为 2
        markarea_opts=opts.MarkAreaOpts(is_silent=True, data=markarea,itemstyle_opts=opts.ItemStyleOpts(color=colors,opacity=0.5))
    )
    return line_chart

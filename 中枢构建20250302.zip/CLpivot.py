import pandas as pd


def generate_zs_square(linelist):
    rushingzs_thd = 0.995
    #设定起始段是上还是下#方向:1上0下
    if linelist[1][1] > linelist[0][1]:
        segdirction = 1 
        zsdirection = 1
        zs_startx, zs_starty,zs_endx, zs_endy = linelist[0][0],linelist[1][1],linelist[1][0],linelist[0][1]
    else:
        segdirction = 0 
        zsdirection = 0
        zs_startx, zs_starty,zs_endx, zs_endy = linelist[0][0],linelist[0][1],linelist[1][0],linelist[1][1]
    #中枢内笔数量
    curzs_lenth = 1
    #保存中枢列表
    zx_list = []
    #中枢可能结束标志
    dirmaychange = 0
    #中枢可能结束时对比的高低点
    dirmaychangehigh = 0
    dirmaychangelow = 0
    zxmaychangestartx = 0
    
    
    for i in range(2,len(linelist)):
        curx = linelist[i][0]
        cury = linelist[i][1]
        #变更笔方向
        segdirction = 1 - segdirction
        #当前整体方向向上
        if zsdirection == 1:
            #当前笔向上
            if segdirction == 1:
                #如果破之前高点则取消转换方向
                if (cury > dirmaychangehigh) and (dirmaychange == 1):
                    dirmaychange = 0
                #第一种情况：向上一笔比当前中枢低，则上一个中枢结束，在反方向产生新中枢
                if (cury <= zs_endy*(2-rushingzs_thd)):
                    if curzs_lenth >= 3:
                        zs_endx = linelist[i-3][0]
                        zx_list.append(generate_zhongshu_position(zs_startx,zs_starty,zs_endx, zs_endy))
                    curzs_lenth = 2
                    zsdirection = 0
                    zs_startx, zs_starty, zs_endx, zs_endy = linelist[i-1][0],linelist[i][1],linelist[i][0],linelist[i-1][1]
                #第二种情况：向上一笔比中枢高点底。低点高
                elif (cury > zs_endy*(2-rushingzs_thd)) and (cury < zs_starty):
                     curzs_lenth =  curzs_lenth + 1
                     zs_starty = cury
                     zs_endx = curx
                #第三种情况：向上一笔高于中枢高点
                elif (cury >= zs_starty):
                    curzs_lenth =  curzs_lenth + 1
                    zs_endx = curx
            #当前笔向下
            elif segdirction == 0:
                #先判断是否转换方向
                if (cury < dirmaychangelow) and (dirmaychange == 1):
                    zsdirection = 0
                    zs_startx = zxmaychangestartx
                    zs_endx = linelist[i][0]
                    dirmaychange = 0

                #第一种情况：向下一笔比当前中枢高,则上一个中枢结束，新的中枢产生
                elif (cury >= zs_starty*rushingzs_thd):
                    if curzs_lenth >= 3:
                        zs_endx = linelist[i-2][0]
                        zx_list.append(generate_zhongshu_position(zs_startx,zs_starty,zs_endx, zs_endy))
                    curzs_lenth = 2
                    zs_startx, zs_starty, zs_endx, zs_endy = linelist[i-1][0],linelist[i-1][1],linelist[i][0],linelist[i][1]
                    #此时可能转换方向
                    dirmaychange = 1
                    dirmaychangehigh = linelist[i-1][1]
                    dirmaychangelow = linelist[i][1]
                    zxmaychangestartx = linelist[i][0]
                #第二种情况，向下一笔比中枢高点底。低点高
                elif (cury < zs_starty*rushingzs_thd) and (cury > zs_endy):
                    curzs_lenth =  curzs_lenth + 1
                    zs_endy = cury
                    zs_endx = curx
                #第三种情况，向下一笔比中枢低点底
                elif (cury <= zs_endy):
                    curzs_lenth =  curzs_lenth + 1
                    zs_endx = curx

        
        #当前整体方向向下
        elif zsdirection == 0:
            #当前笔向上
            if segdirction == 1:
                 #先判断是否转换方向
                if (cury > dirmaychangehigh) and (dirmaychange == 1):
                    zsdirection = 1
                    zs_startx = zxmaychangestartx
                    zs_endx = linelist[i][0]
                    dirmaychange = 0
                #第一种情况：向上一笔比当前中枢低,则上一个中枢结束，新的中枢产生
                if (cury <= zs_endy*(2-rushingzs_thd)):
                    if curzs_lenth >= 3:
                        zs_endx = linelist[i-2][0]
                        zx_list.append(generate_zhongshu_position(zs_startx,zs_starty,zs_endx, zs_endy))
                    curzs_lenth = 2
                    zs_startx, zs_starty, zs_endx, zs_endy = linelist[i-1][0],linelist[i][1],linelist[i][0],linelist[i-1][1]
                    #此时可能转换方向
                    dirmaychange = 1
                    dirmaychangehigh = linelist[i][1]
                    dirmaychangelow = linelist[i-1][1]
                    zxmaychangestartx = linelist[i][0]
                #第二种情况，向上一笔比中枢高点底。低点高
                elif (cury > zs_endy*(2-rushingzs_thd)) and (cury < zs_starty):
                    curzs_lenth =  curzs_lenth + 1
                    zs_starty = cury
                    zs_endx = curx
                #第三种情况 向上一笔比中枢高点高
                elif (cury >= zs_starty):
                    curzs_lenth =  curzs_lenth + 1
                    zs_endx = curx
            #当前笔向下
            elif segdirction == 0:
                #如果破之前高点则取消转换方向
                if (cury < dirmaychangelow) and (dirmaychange == 1):
                    dirmaychange = 0
                #第一种情况，向下一笔比当前中枢高，则上一个中枢结束，在反方向产生新中枢
                if (cury >= zs_starty*rushingzs_thd):
                    if curzs_lenth >= 3:
                        zs_endx = linelist[i-3][0]
                        zx_list.append(generate_zhongshu_position(zs_startx,zs_starty,zs_endx, zs_endy))
                    curzs_lenth = 2
                    zsdirection = 1
                    zs_startx, zs_starty, zs_endx, zs_endy = linelist[i-1][0],linelist[i-1][1],linelist[i][0],linelist[i][1]
                #第二种情况：向下一笔比中枢高点底。低点高
                elif (cury < zs_starty*rushingzs_thd) and (cury > zs_endy):
                    curzs_lenth = curzs_lenth + 1
                    zs_endy = cury
                    zs_endx = curx
                #第三种情况：向下一笔比低点低
                elif (cury <= zs_endy):
                    curzs_lenth =  curzs_lenth + 1
                    zs_endx = curx
            
    return zx_list

def is_in_interval(intervals, x):
    for interval in intervals:
        if interval[0] <= x <= interval[1]:
            return interval
    return False

def generate_zxmarklist(seg_1min, zx_markarea):
    zsmarklist = []
    for each in zx_markarea:
        start = each[0]['xAxis']
        end = each[1]['xAxis']
        zsmarklist.append([start,end])
    
    segup = [seg_1min[0]]
    #判断是否出中枢
    judgezx = []
    #判断中枢内有几笔
    zs_bi = 1

    #当前笔的方向
    if seg_1min[1][1] > seg_1min[0][1]:
        cursegdir = 1
    elif seg_1min[1][1] < seg_1min[0][1]:
        cursegdir = 0
    #中枢的方向 1上0下
    zsdir = cursegdir
    #上一个段的顶点
    last_seg_point = cursegdir
    
    for i in range(1,len(seg_1min)):
        curx = seg_1min[i][0]
        cury = seg_1min[i][1]
        lastx = seg_1min[i-1][0]
        lasty = seg_1min[i-1][1]
        cursegdir = 1 - cursegdir
        curzs = is_in_interval(zsmarklist, curx)
        #当前点在中枢里curzs
        if curzs != False:
            #判断是否进入新的中枢
            #如果进入新的中枢
            if curzs != judgezx:
                if zs_bi < 8:
                    if zs_bi in (3,4,5):
                        segup.pop()
                    elif zs_bi in (6,7):
                        segup.pop()
                        segup.pop()
                elif zs_bi >= 8:
                    if cursegdir == last_seg_point:
                        segup.pop()
                #中枢刷新，笔数重新计算
                judgezx = curzs
                zs_bi = 1
                zsdir = cursegdir
            #没有进入新的中枢
            else:
                #则笔数+1
                zs_bi = zs_bi + 1
                #如果走了3段就加入一个段
                if zs_bi%3 == 0:
                    segup.append(seg_1min[i])
                    #同时这个顶点的方向为本笔的方向
                    last_seg_point = cursegdir
        #当前点不在中枢里
        else:
            #zs_bi = zs_bi + 1
            if zs_bi < 8:
                if zs_bi in (3,4,5):
                    segup.pop()
                elif zs_bi in (6,7):
                    segup.pop()
                    segup.pop()
            elif zs_bi >= 8:
                if cursegdir == last_seg_point:
                    segup.pop()
            judgezx = []
            zs_bi = 0
            if (not is_in_interval(zsmarklist, lastx)) and (not is_in_interval(zsmarklist, curx)):
                pass
            else:
                segup.append(seg_1min[i])
    return segup

#将坐标打包为列表
def generate_zhongshu_position(start_x,start_y,end_x,end_y):
    tmp_list = []
    #构造起点坐标
    tmp_position_start = {'xAxis': 0, 'yAxis': 0}
    tmp_position_start['xAxis'] = start_x
    tmp_position_start['yAxis'] = start_y
    tmp_list.append(tmp_position_start)

    #构造终点坐标
    tmp_position_end = {'xAxis': 0, 'yAxis': 0}
    tmp_position_end['xAxis'] = end_x
    tmp_position_end['yAxis'] = end_y
    tmp_list.append(tmp_position_end)
    #print(tmp_list)
    #存储完成的中枢坐标
    return tmp_list